#!/bin/bash
/usr/local/bin/build_ada
